#!/usr/bin/env python
# coding: utf-8

# # BIKE SHARING ASSIGNMENT 

# In[1]:


import warnings

warnings.filterwarnings('ignore')


# In[2]:


#importing the necessary libraries 
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import seaborn as sns 
 


# ## Reading and Understanding the Data 

# In[3]:


#Reading the days.csv file into the notebook 
df= pd.read_csv("day.csv") 
df.head()


# In[4]:


#Inspecting the shape of the dataframe 
df.shape


# In[5]:


#Looking into the statistical summary of the data
df.describe()


# In[6]:


df.info()


# - It can be seen that the categorical columns like 'season', 'yr', 'mnth', 'holiday', 'weekday', 'workingday' and 'weathersit' have been represented numerically and hence have int datatype assigned to them. 
# These values must be converted to categorical string values so that the model does not interpret them as having a ranking of any sort and give incorrect results.  
# 
# - Then the columns 'instant' and 'dteday' doesn't seem to be of any importance here, so it's better to drop them here.
# 

# In[7]:


# Checking values of season column
df.season.value_counts()


# In[8]:


# Now, moving on to changing the numerical values in categorical columns to string values. 
# Changing values of 'season' column to strings
def obj_map1(x):
    return x.map({1:'Spring',2:'Summer',3:'Fall',4:'Winter'})

df[['season']] = df[['season']].apply(obj_map1) 

# Checking if the changes have been made 
df.season.value_counts()


# In[9]:


# Checking values of yr column
df.yr.value_counts()


# In[10]:


# Changing values of 'yr' column to strings 
def obj_map2(x):
    return x.map({0:'2018',1:'2019'})

df[['yr']] = df[['yr']].apply(obj_map2) 

# Checking if the changes have been made 
df.yr.value_counts()


# In[11]:


# Checking values of 'mnth' column 
df.mnth.value_counts()


# In[12]:


# Changing values of 'mnth' column to strings 
def obj_map3(x):
    return x.map({1:'Jan',2:'Feb',3:'Mar',4:'Apr',5:'May',6:'Jun',7:'Jul',8:'Aug',9:'Sep',10:'Oct',11:'Nov',12:'Dec'})

df[['mnth']] = df[['mnth']].apply(obj_map3) 

# Checking if the changes have been made 
df.mnth.value_counts()


# In[13]:


# Checking values of holiday column 
df.holiday.value_counts()


# In[14]:


# Changing values of 'holiday' column to strings, taking 0 as a not a holiday and 1 as a holiday because the value 1 has lesser entries and is more likely to represent the holidays in a year.
def obj_map4(x):
    return x.map({0:'Not Holiday',1:'Holiday'})

df[['holiday']] = df[['holiday']].apply(obj_map4) 

# Checking if the changes have been made 
df.holiday.value_counts()


# In[15]:


# Checking values of weekday column
df.weekday.value_counts()


# In[16]:


# Checking dates and weekday column values, to help identify which number corresponds to what day of the week in the dataset
df[["dteday","weekday"]]


# In[17]:


# To find out which week day correpsonds to each number in 'weekday' column we try using the datetime function in python 
import datetime 
import calendar 
  
def findDay(date): 
    dayofweek = datetime.datetime.strptime(date, '%d %m %Y').weekday() 
    return (calendar.day_name[dayofweek]) 
  
# The check 
date = '29 12 2019'
print(findDay(date))  

date= '30 12 2019' 
print(findDay(date))


# In[18]:


# Changing values of 'weekday' column to strings. 
# The labels for the values were decided upon by checking the day of date 29-12-2019 in the dataset which had value 0 in weekday column and same way value 1 was found to correspond to Monday.
def obj_map5(x):
    return x.map({0:'Sunday',1:'Monday',2:'Tuesday',3:'Wednesday',4:'Thursday',5:'Friday',6:'Saturday'})

df[['weekday']] = df[['weekday']].apply(obj_map5) 

# Checking if the changes have been made 
df.weekday.value_counts()


# In[19]:


# Checking values of working day column 
df.workingday.value_counts()


# In[20]:


# Changing values of 'workingday' column to strings 
def obj_map6(x):
    return x.map({0:'Non-working day',1:'Working day'})

df[['workingday']] = df[['workingday']].apply(obj_map6) 

# Checking if the changes have been made 
df.workingday.value_counts()


# In[21]:


# Checking values of weathersit column 
df.weathersit.value_counts()


# In[22]:


# Changing values of 'weathersit' column to strings  
# As per data dictionary the values assigned to labels are as folows, but in the data set only 1, 2 and 3 values exist 
#- 1: Clear, Few clouds, Partly cloudy, Partly cloudy 
#- 2: Mist + Cloudy, Mist + Broken clouds, Mist + Few clouds, Mist
#- 3: Light Snow, Light Rain + Thunderstorm + Scattered clouds, Light Rain + Scattered clouds
#- 4: Heavy Rain + Ice Pallets + Thunderstorm + Mist, Snow + Fog 
# So, here its understood that the given dataset is probabaly a subset of the original and hence the value 4 is missing 
# Here, the strings are renamed as follows 1: Clear, 2: Partially Clear, 3: Slightly Bad Weather
def obj_map7(x):
    return x.map({1:'Clear',2:'Partially Clear',3:'Slightly Bad Weather'})

df[['weathersit']] = df[['weathersit']].apply(obj_map7) 

# Checking if the changes have been made 
df.weathersit.value_counts()


# In[23]:


#Deleting the columns 'instant' and 'dteday' 
del df['instant']
del df['dteday']


# In[24]:


# Checking the new dataframe to see if the columns 'instant' and 'dteday' have been removed
df.head()


# In[25]:


# Inspecting the columns and dataypes 
df.info()


# - All the columns have the right datatypes now, so we move on to data visualisation 

# ## Data Visualisation

# In[26]:


# First the categorical columns are visualised  
df_categorical=df.select_dtypes(exclude=['float64','int64'])
df_categorical.columns 


# In[27]:


# Plotting boxplots of categorical columns vs target varable= 'cnt' 

plt.figure(figsize=(20,20)) 
plt.subplot(3,3,1) 
sns.boxplot(x='season',y='cnt',data=df) 
plt.subplot(3,3,2) 
sns.boxplot(x='yr',y='cnt',data=df) 
plt.subplot(3,3,3) 
sns.boxplot(x='mnth',y='cnt',data=df) 
plt.subplot(3,3,4) 
sns.boxplot(x='holiday',y='cnt',data=df) 
plt.subplot(3,3,5) 
sns.boxplot(x= 'weekday',y='cnt',data=df) 
plt.subplot(3,3,6) 
sns.boxplot(x='workingday',y='cnt',data=df) 
plt.subplot(3,3,7) 
sns.boxplot(x='weathersit',y='cnt',data=df) 
plt.show()


# The observations from the boxplots are as follows,
# - The data seems to be fairly well behaved with most categorical columns having no outliers, the only ones that do have outliers are season and yr columns but the outliers are not that much so we leave them as such. 
# - The number of users of the bike sharing service seem to be higher in the year 2019 than in 2018.  
# - The number of users are higher in summer and fall months, which is generally categorised by calmer weather. 
# - There are more users of the bike sharing service in a clear weathersit, which is the most favourable condition for bike riding. 
# - Whether the day is a working day or not does not seem to have any effect on the number of users, a similar trend can be seen for days of the week. 
# - The months of January, February, November and December have fewer users when compared to other months, this could be due to the fact that these months generally have harsher weather conditions which are not favourable for bike riding. 
# - From the boxplot of cnt vs holiday, it can be seen that the median of users in days that are holidays is lower than that of users in days which are not holidays.

# In[28]:


# Visulaisation of Numerical Columns 
df_numerical=df.select_dtypes(include=['int64','float64']) 
df_numerical.columns


# In[29]:


# Distplots of numerical columns
plt.figure(figsize=(20,20)) 
plt.subplot(3,3,1) 
sns.distplot(df['temp']) 
plt.subplot(3,3,2) 
sns.distplot(df['atemp']) 
plt.subplot(3,3,3) 
sns.distplot(df['hum']) 
plt.subplot(3,3,4) 
sns.distplot(df['windspeed']) 
plt.subplot(3,3,5) 
sns.distplot(df['casual']) 
plt.subplot(3,3,6) 
sns.distplot(df['registered']) 
plt.subplot(3,3,7) 
sns.distplot(df['cnt']) 
plt.show()


# - The variables 'cnt','registered', 'hum' and 'windspeed' seem to follow a normal distribution while the rest do not.

# In[30]:


# Pairplots of numerical columns 
plt.figure(figsize=(20,20))
sns.pairplot(df_numerical[['temp', 'atemp', 'hum', 'windspeed', 'casual', 'registered', 'cnt']])
plt.show()


# The observations from the pairplot are as follows, 
# - There seems to be a positive correlation for cnt column with the columns temp,atemp, casual and registered(this particular correlation being very high). 
# - There seems to be a very high positive correlation between temp and atemp. 

# In[31]:


# To understand the correlations better we use a correlation matrix and visulaise the same using a heatmap. 
correlation= df_numerical.corr() 
correlation


# In[32]:


# Visualising using heatmap 
mask = np.array(correlation)
mask[np.tril_indices_from(mask)]=False
plt.figure(figsize=(12,12))
sns.heatmap(correlation,mask=mask,annot=True);
plt.tight_layout()


# - From the heatmap above it can be clearly seen that temp and atemp are highly correlated,thus this is a case of multicollinearity. To avoid problems created by multicollinearity in model building, the 'atemp' column is chosen for dropping. 
# - The columns regsitered and casual are highly correlated with the target variable cnt, and since cnt is basically a sum of the casual and registered columns it's better to drop them here as they will not be of much use in this study.

# In[33]:


#Dropping the columns 'casual', 'registered' and 'atemp' 
del df['atemp'] 
del df['casual'] 
del df['registered'] 

# Checking if the changes have been made, 
df.head()


# ## Data Preparation 

# The data preparation phase consists of three parts 
# 1. One Hot Encoding of Categroical Variables 
# 2. Train Test Split 
# 3. Scaling of the numerical columns (target variable 'cnt' is not scaled)

# In[34]:


df_categorical=df.select_dtypes(include=['object']) 
df_categorical.columns


# In[35]:


# OHE of categorical variables 
df_dummies=pd.get_dummies(df_categorical,drop_first=True) 
df_dummies.head()


# In[36]:


#Dropping the categorical columns from original dataframe
df.drop(df_categorical.columns,axis=1,inplace=True) 


# In[37]:


#Checking the original dataframe to see if changes have been made 
df.head()


# In[38]:


# Adding the dummies to the original dataframe 
df = pd.concat([df, df_dummies],axis=1)


# In[39]:


# Checking the original datframe again. 
df.head()


# In[40]:


df.shape


# In[41]:


# Moving on to test-train split 
import sklearn 
from sklearn.model_selection import train_test_split 
df_train,df_test = train_test_split(df,train_size=0.7,random_state=100) 
print(df_train.shape) 
print(df_test.shape)


# In[42]:


# Scaling of numerical columns 
from sklearn.preprocessing import MinMaxScaler 
scaler= MinMaxScaler() 
numerical_variables=['temp','hum','windspeed','cnt'] 
df_train[numerical_variables]=scaler.fit_transform(df_train[numerical_variables]) 
df_train.head()


# With this the data preparation is complete and we move on to training the model 

# ## Training the Model 

# In[43]:


# Getting X_train and y_train 
X_train=df_train 
y_train=df_train.pop('cnt') 


# In[44]:


# Building a model with all vraiables 
import statsmodels.api as sm
X_train_sm=sm.add_constant(X_train) 
lr=sm.OLS(y_train,X_train_sm) 
lr_model=lr.fit() 
lr_model.summary()


# In[45]:


# Making Predictions on this model 
# Firstly,scaling numerical variables of the test dataset 
df_test[numerical_variables]=scaler.transform(df_test[numerical_variables]) 
df_test.head() 


# In[46]:


# Getting X_test and y_test 
y_test= df_test.pop('cnt') 
X_test= df_test


# In[47]:


# Adding a constant 
X_test_sm=sm.add_constant(X_test) 
X_test_sm.head()


# In[48]:


# Making the predictions 
y_test_pred=lr_model.predict(X_test_sm)


# In[49]:


# Evaluating this model 
from sklearn.metrics import r2_score 
r2_score(y_true=y_test,y_pred=y_test_pred) 


# This R-squared value is comparable to the one obtained during training (which was = 0.85), thus we can conclude that the model is able to generalise what it learned pretty well.

# In[50]:


# Model Building Using RFE 
from sklearn.feature_selection import RFE 
from sklearn.linear_model import LinearRegression 

# Running RFE with the output number of the varaiables equal to 20 
lm= LinearRegression() 
lm.fit(X_train,y_train) 
rfe=RFE(lm,20) 
rfe= rfe.fit(X_train,y_train)


# In[51]:


list(zip(X_train.columns,rfe.support_,rfe.ranking_))


# In[52]:


col= X_train.columns[rfe.support_] 
col


# In[53]:


# Building a model using columns selected by RFE  
X_train_rfe = X_train[X_train.columns[rfe.support_]]
X_train_rfe.head()


# In[54]:


# Checking shape of X_train_rfe 
X_train_rfe.shape


# In[55]:


X_train_rfe_sm= sm.add_constant(X_train_rfe) 
lr2=sm.OLS(y_train,X_train_rfe_sm) 
lr2_model=lr2.fit() 
lr2_model.summary()


# In[56]:


#Getting the columns that were removed by RFE 
removed_columns=X_train.columns[~rfe.support_] 
removed_columns


# In[57]:


# Making Predictions 
X_test_rfe_sm=sm.add_constant(X_test) 
X_test_rfe_sm.head()


# In[58]:


# Removing columns that were not selected by RFE  from X_test_rfe_sm  
X_test_rfe_sm.drop(removed_columns,axis=1,inplace=True)


# In[59]:


X_test_rfe_sm.shape


# In[60]:


X_test_rfe_sm.columns


# In[61]:


y_test_rfe_pred=lr2_model.predict(X_test_rfe_sm)


# In[62]:


r2_score(y_true=y_test,y_pred=y_test_rfe_pred)


# - Once again the R-squared values shows that the model built using RFE selected variables is able to generalise what it learned well. 
# - Comparing the adjusted R-squared values of the models built with and without using RFE, it can be seen that the adjusted R-squared value of RFE model is slightly higher than that of the other.(Adjusted R squared of RFE model= 0.842 and the other model's = 0.841) 
# - Thus, we can see that the RFE selected model is able to make predictions just as well as the one without using RFE. So, here we proceed with the RFE model and continue to work on it to arrive at a better linear regression model.

# ## Training the Model

# In[63]:


# Final Model Building 
lr2_model.summary()


# In[64]:


# VIF Calculation 
from statsmodels.stats.outliers_influence import variance_inflation_factor 
vif= pd.DataFrame() 
vif['Features']= X_train_rfe.columns 
vif['VIF']=[variance_inflation_factor(X_train_rfe.values,i) for i in range(X_train_rfe.shape[1])] 
vif['VIF']= round(vif['VIF'],2) 
vif= vif.sort_values(by='VIF',ascending=False) 
vif


# In[65]:


#It can be observed that the weekday_Sunday variable has the highest p-value and has the third highest VIF value 
# Hence, we drop the weekday_Sunday variable 
del X_train_rfe['weekday_Sunday'] 
X_train_rfe.shape


# In[66]:


# Building another model 
X_train_rfe_sm=sm.add_constant(X_train_rfe) 
lr2=sm.OLS(y_train,X_train_rfe_sm) 
lr2_model=lr2.fit() 
lr2_model.summary()


# In[67]:


#VIF 
from statsmodels.stats.outliers_influence import variance_inflation_factor 
vif= pd.DataFrame() 
vif['Features']= X_train_rfe.columns 
vif['VIF']=[variance_inflation_factor(X_train_rfe.values,i) for i in range(X_train_rfe.shape[1])] 
vif['VIF']= round(vif['VIF'],2) 
vif= vif.sort_values(by='VIF',ascending=False) 
vif


# - The R-squared value hasn't changed but there is a definite change in VIF values indicating that weekday_Sunday was causing a problem of multicollinearity. 
# - weekday_Saturday has very high p-value, despite having a low VIF value, so in the next step we drop this column 

# In[68]:


del X_train_rfe['weekday_Saturday'] 
X_train_rfe.shape


# In[69]:


# Building another model  
X_train_rfe_sm=sm.add_constant(X_train_rfe) 
lr2=sm.OLS(y_train,X_train_rfe_sm) 
lr2_model=lr2.fit() 
lr2_model.summary()


# In[70]:


#VIF 
from statsmodels.stats.outliers_influence import variance_inflation_factor 
vif= pd.DataFrame() 
vif['Features']= X_train_rfe.columns 
vif['VIF']=[variance_inflation_factor(X_train_rfe.values,i) for i in range(X_train_rfe.shape[1])] 
vif['VIF']= round(vif['VIF'],2) 
vif= vif.sort_values(by='VIF',ascending=False) 
vif


# In[71]:


#Again no change in R-squared value, the next variable that has high p-value despite low vif to be removed is mnth_Feb 
del X_train_rfe['mnth_Feb'] 
X_train_rfe.shape


# In[72]:


#Buidling another model 
X_train_rfe_sm=sm.add_constant(X_train_rfe) 
lr2=sm.OLS(y_train,X_train_rfe_sm) 
lr2_model=lr2.fit() 
lr2_model.summary()


# In[73]:


#VIF 
from statsmodels.stats.outliers_influence import variance_inflation_factor 
vif= pd.DataFrame() 
vif['Features']= X_train_rfe.columns 
vif['VIF']=[variance_inflation_factor(X_train_rfe.values,i) for i in range(X_train_rfe.shape[1])] 
vif['VIF']= round(vif['VIF'],2) 
vif= vif.sort_values(by='VIF',ascending=False) 
vif


# In[74]:


#The R-squared has dropped slightly 
# The next variable to be dropped is weekday Tuesday because of high p-value even though it has lowest vif value 
del X_train_rfe['weekday_Tuesday'] 
X_train_rfe.shape 


# In[75]:


#Buidling another model 
X_train_rfe_sm=sm.add_constant(X_train_rfe) 
lr2=sm.OLS(y_train,X_train_rfe_sm) 
lr2_model=lr2.fit() 
lr2_model.summary()


# In[76]:


#VIF 
from statsmodels.stats.outliers_influence import variance_inflation_factor 
vif= pd.DataFrame() 
vif['Features']= X_train_rfe.columns 
vif['VIF']=[variance_inflation_factor(X_train_rfe.values,i) for i in range(X_train_rfe.shape[1])] 
vif['VIF']= round(vif['VIF'],2) 
vif= vif.sort_values(by='VIF',ascending=False) 
vif


# In[77]:


# The R-squared value has dropped again, this time adjusted R-squared has also dropped 
# The p-values of all varaibles are in acceptable range now,so now start dropping variables with high vif values 
# Thus we drop 'hum' variable 
del X_train_rfe['hum'] 
X_train_rfe.shape 


# In[78]:


#Buidling another model 
X_train_rfe_sm=sm.add_constant(X_train_rfe) 
lr2=sm.OLS(y_train,X_train_rfe_sm) 
lr2_model=lr2.fit() 
lr2_model.summary()


# In[79]:


#VIF 
from statsmodels.stats.outliers_influence import variance_inflation_factor 
vif= pd.DataFrame() 
vif['Features']= X_train_rfe.columns 
vif['VIF']=[variance_inflation_factor(X_train_rfe.values,i) for i in range(X_train_rfe.shape[1])] 
vif['VIF']= round(vif['VIF'],2) 
vif= vif.sort_values(by='VIF',ascending=False) 
vif


# In[80]:


# R-squared and adjusted R-squared has dropped 
# holiday_Not Holiday is to be dropped because it has very vif value 
del X_train_rfe['holiday_Not Holiday'] 
X_train_rfe.shape 


# In[81]:


#Buidling another model 
X_train_rfe_sm=sm.add_constant(X_train_rfe) 
lr2=sm.OLS(y_train,X_train_rfe_sm) 
lr2_model=lr2.fit() 
lr2_model.summary()


# In[82]:


#VIF 
from statsmodels.stats.outliers_influence import variance_inflation_factor 
vif= pd.DataFrame() 
vif['Features']= X_train_rfe.columns 
vif['VIF']=[variance_inflation_factor(X_train_rfe.values,i) for i in range(X_train_rfe.shape[1])] 
vif['VIF']= round(vif['VIF'],2) 
vif= vif.sort_values(by='VIF',ascending=False) 
vif


# In[83]:


#Now the workingday_Working day has high p-value so we drop that 
del X_train_rfe['workingday_Working day'] 
X_train_rfe.shape 


# In[84]:


#Buidling another model 
X_train_rfe_sm=sm.add_constant(X_train_rfe) 
lr2=sm.OLS(y_train,X_train_rfe_sm) 
lr2_model=lr2.fit() 
lr2_model.summary()


# In[85]:


#VIF 
from statsmodels.stats.outliers_influence import variance_inflation_factor 
vif= pd.DataFrame() 
vif['Features']= X_train_rfe.columns 
vif['VIF']=[variance_inflation_factor(X_train_rfe.values,i) for i in range(X_train_rfe.shape[1])] 
vif['VIF']= round(vif['VIF'],2) 
vif= vif.sort_values(by='VIF',ascending=False) 
vif


# Now all the variables have p-values in the acceptable range and the vif values seem to be accaptable too, even though temp has vif value slightly greater than 5 it can be left as such because of the range of vif values seen in other variables.  

# ## Residual Analysis and Predictions

# In[86]:


## Residual Analysis and Predictions 
y_train_rfe_pred=lr2_model.predict(X_train_rfe_sm)
res=y_train-y_train_rfe_pred 
sns.distplot(res) 


# The distribution is centered around 0 and is normal,so from the residual analysis of the error terms we can conclude that the model is reliable.

# In[87]:


# Predictions and Evaluation on the test set 
X_test_rfe_sm=sm.add_constant(X_test) 
X_test_rfe_sm.drop(removed_columns,axis=1,inplace=True) 
del X_test_rfe_sm['weekday_Sunday'] 
del X_test_rfe_sm['weekday_Saturday'] 
del X_test_rfe_sm['mnth_Feb'] 
del X_test_rfe_sm['weekday_Tuesday'] 
del X_test_rfe_sm['hum'] 
del X_test_rfe_sm['holiday_Not Holiday'] 
del X_test_rfe_sm['workingday_Working day'] 
X_test_rfe_sm.shape


# In[88]:


y_test_rfe_pred=lr2_model.predict(X_test_rfe_sm) 
r2_score(y_true=y_test,y_pred=y_test_rfe_pred)


# This R-squared value is comparable with that of the training set, so we can conclude that the model has generalised what it has learned well.

# Thus our final model i.e. equation of the best fitted line is, 
# cnt= 0.4362*temp + -0.1597*windspeed + -0.0749*season_Spring + 0.0343*season_Summer + 0.0862*season_Winter + 0.2349*yr_2019 + -0.0439*mnth_Dec + -0.0513*mnth_Jan + -0.0491*mnth_Jul + -0.0476*mnth_Nov + 0.0645*mnth_Sep + -0.0786*weathersit_Partially Clear + -0.2886*weathersit_Slightly Bad Weather  

# - From the equation above it can be seen that temperature has a high positive influence on the number of users of bike sharing service.Warmer days are better for bike riding. 
# - A slightly bad weather which includes light rain,snow etc, has a high negative impact on the number of users because such conditions are unfavourable for the use of bikes. 
# - The other factor that has a high negative influence is windspeed, which is obvious since greater the windspeed, the more difficult it is to ride a bike. 
# - In general it can be concluded that the demand for the bike sharing service is higher during warmer and calmer weather conditions with low wind speeds. Also the popularity of the bike sharing service seems to have increased from 2018 to 2019 which is a sure sign that more and more people are becoming open to using shared bikes as a means of transport. 
# - If the company can develop appropriate strategies keeping the above factors in mind, they can surely run a profitable business once the covid-19 restrictions are eased.

# In[ ]:




