#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import random
import os


# In[3]:


def fix_seed(seed):
    # random
    random.seed(seed)
    # Numpy
    np.random.seed(seed)

SEED = 42
fix_seed(SEED)


# ESサイトのユーザーに対して**RCT**を適用したメールマーケティングを行ったデータ。

# In[5]:


# データのロード
base_path = "/Users/ryoto/workspace/hit-u/zemi/econome_ml_demo/data"
mail = pd.read_csv(os.path.join(base_path,'E-MailAnalytics.csv'))
print(mail.shape)
mail.head()


# In[6]:


print("num of No E-Mail : ", len(mail.query("segment == 'No E-Mail'")))
print("num of Mens E-Mail : ", len(mail.query("segment == 'Womens E-Mail'")))
print("num of No Womens : ", len(mail.query("segment == 'Mens E-Mail'")))


# ## RCTのデータからATEを求めてBaseLineとする
# 簡略化のために女性向けのメールが配信されているデータを削除する。

# In[7]:


mail_df = mail.query("segment != 'Womens E-Mail'")
print(len(mail_df.query("segment == 'No E-Mail'")))
print(len(mail_df.query("segment == 'Womens E-Mail'")))
print(len(mail_df.query("segment == 'Mens E-Mail'")))


# In[8]:


mail_df["segment"] = mail_df.segment.map(lambda x: 1 if x == 'Mens E-Mail' else 0)
mail_df = mail_df.rename(columns={"segment" : "treatment"})
mail_df.head()


# In[9]:


mail_df.groupby("treatment").agg({"spend" : "mean", "conversion": "mean", "visit":"count"}).rename(columns={"visit" : "count"})


# In[10]:


# treatment 0, 1 のデータフレームに分ける
treatment_1 = mail_df.query("treatment == 1")
treatment_0 = mail_df.query("treatment == 0")

# 介入が購買金額に与えた影響を計算する
ts_1 = treatment_1["spend"].mean()
ts_0 = treatment_0["spend"].mean()
print("介入が購買金額に与えた影響は,", np.round(ts_1 - ts_0, 3))

# 介入がconversionに与えた影響を計算する
tc_1 = treatment_1["conversion"].mean()
tc_0 = treatment_0["conversion"].mean()
True_ATE = np.round((tc_1 - tc_0), 5)
print("介入がconversionに与えた影響は,", True_ATE)


# ## データの前処理

# In[37]:


mail_df.head()


# In[38]:


# ラベルエンコーディング（OrdinalEncoder）
from sklearn.preprocessing import OrdinalEncoder

oe = OrdinalEncoder()
encoded = oe.fit_transform(mail_df[['history_segment', 'zip_code', "channel"]].values)
# decoded = oe.inverse_transform(encoded)

print('エンコード結果: ')
encoded_df = pd.DataFrame(encoded, columns = ["history_segment", "zip_code", "channel"])
encoded_df.head()


# In[39]:


mail_df_use = mail_df[
    ['recency', 'history', 'mens', 'womens', 'newbie', 'treatment', 'visit', 'conversion', 'spend']
    ]
demo_df = pd.concat([mail_df_use.reset_index(), encoded_df], axis = 1).drop(columns = "index")
print(demo_df.shape)
demo_df.head()


# In[40]:


from sklearn.model_selection import train_test_split
train_df, val_df = train_test_split(demo_df, test_size= 0.2,random_state=SEED)
print(train_df.shape)
print(val_df.shape)


# ## Econmlで試す

# In[41]:


# Main imports
from econml.metalearners import TLearner, SLearner, XLearner, DomainAdaptationLearner

# Helper imports 
import numpy as np
from numpy.random import binomial, multivariate_normal, normal, uniform
import lightgbm as lgb
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier, GradientBoostingRegressor, GradientBoostingClassifier
import matplotlib.pyplot as plt


# In[42]:


# set data 
Y = train_df.conversion
T = train_df.treatment
X = train_df.drop(columns=["conversion", "treatment", "spend", "visit"])
X_val = val_df.drop(columns=["conversion", "treatment", "spend", "visit"])


# ### T-Learner

# In[43]:


# Instantiate T learner
models = RandomForestRegressor(n_estimators=1000, max_depth=10, min_samples_leaf=64, random_state = 42)
T_learner = TLearner(models=models)
# Train T_learner
T_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
T_te = T_learner.effect(X_val)

print("True ATE : ", True_ATE)
pred_ATE_T = np.round(T_learner.ate(X_val), 5)
print("Predict ATE : ", pred_ATE_T)


# ### S-Learner

# In[44]:


# Instantiate S learner
overall_model = RandomForestRegressor(n_estimators=1000, max_depth=6, min_samples_leaf=64, random_state = 42)
S_learner = SLearner(overall_model=overall_model)
# Train S_learner
S_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
S_te = S_learner.effect(X_val)

print("True ATE : ", True_ATE)
pred_ATE_S = np.round(S_learner.ate(X_val), 5)
print("Predict ATE : ", pred_ATE_S)


# ### X-Learner

# In[45]:


# Instantiate X learner
models = RandomForestRegressor(n_estimators=1500, max_depth= 10 , min_samples_leaf=64, random_state = 42)
propensity_model = RandomForestClassifier(n_estimators=500, max_depth = 10 , min_samples_leaf=64, random_state = 42)
X_learner = XLearner(models=models, propensity_model=propensity_model)
# Train X_learner
X_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
X_te = X_learner.effect(X_val)
print("True ATE : ", True_ATE)
pred_ATE_X = np.round(X_learner.ate(X_val), 5)
print("Predict ATE : ", pred_ATE_X)


# # Use_fulldata

# In[46]:


# set data 
Y = demo_df.conversion
T = demo_df.treatment
X = demo_df.drop(columns=["conversion", "treatment", "spend", "visit"])
print(demo_df.shape)


# ## T-Learner

# In[47]:


# Instantiate T learner
models = RandomForestRegressor(n_estimators=1000, max_depth=10,  random_state = 42)
T_learner = TLearner(models=models)
# Train T_learner
T_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
T_te = T_learner.effect(X)

print("True ATE : ", True_ATE)
pred_ATE_T = np.round(T_learner.ate(X), 6)
print("Predict ATE : ", pred_ATE_T)


# In[48]:


# Instantiate T learner
models = GradientBoostingRegressor(n_estimators=1000, max_depth=10,  random_state = 42)
T_learner = TLearner(models=models)
# Train T_learner
T_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
T_te = T_learner.effect(X)

print("True ATE : ", True_ATE)
pred_ATE_T = np.round(T_learner.ate(X), 6)
print("Predict ATE : ", pred_ATE_T)


# ## S-Learner

# In[49]:


# Instantiate S learner
overall_model = RandomForestRegressor(n_estimators=1000, max_depth=10,  random_state = 42)
S_learner = SLearner(overall_model=overall_model)
# Train S_learner
S_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
S_te = S_learner.effect(X)

print("True ATE : ", True_ATE)
pred_ATE_S = np.round(S_learner.ate(X), 5)
print("Predict ATE : ", pred_ATE_S)


# In[50]:


# Instantiate S learner
overall_model = GradientBoostingRegressor(n_estimators=1000, max_depth=10,  random_state = 42)
S_learner = SLearner(overall_model=overall_model)
# Train S_learner
S_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
S_te = S_learner.effect(X)

print("True ATE : ", True_ATE)
pred_ATE_S = np.round(S_learner.ate(X), 5)
print("Predict ATE : ", pred_ATE_S)


# ## X-Learner

# In[51]:


# Instantiate X learner
models = RandomForestRegressor(n_estimators=1000, max_depth=12,  random_state = 42)
propensity_model = RandomForestClassifier(n_estimators=1000, max_depth=12,  random_state = 42)
X_learner = XLearner(models=models, propensity_model=propensity_model)
# Train X_learner
X_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
X_te = X_learner.effect(X)
print("True ATE : ", True_ATE)
pred_ATE_X = np.round(X_learner.ate(X), 5)
print("Predict ATE : ", pred_ATE_X)


# In[52]:


# Instantiate X learner
models = GradientBoostingRegressor(n_estimators=1000, max_depth=12,  random_state = 42)
propensity_model = RandomForestClassifier(n_estimators=1000, max_depth=12,  random_state = 42)
X_learner = XLearner(models=models, propensity_model=propensity_model)
# Train X_learner
X_learner.fit(Y, T, X=X)
# Estimate treatment effects on test data
X_te = X_learner.effect(X)
print("True ATE : ", True_ATE)
pred_ATE_X = np.round(X_learner.ate(X), 5)
print("Predict ATE : ", pred_ATE_X)

