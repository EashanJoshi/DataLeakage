#!/usr/bin/env python
# coding: utf-8

# In[167]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
from scipy.stats import zscore
import statsmodels.api as sm
from scipy import stats
from statsmodels.stats.outliers_influence import variance_inflation_factor
from sklearn.linear_model import LinearRegression,Lasso,Ridge
from sklearn.metrics import mean_squared_error, mean_absolute_error,r2_score
from sklearn.model_selection import train_test_split,cross_val_score,GridSearchCV
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor


# ### Importing Dataset

# In[168]:


df=pd.read_csv("https://raw.githubusercontent.com/dsrscientist/DSData/master/happiness_score_dataset.csv")


# In[169]:


df


# In[170]:


df.shape

From the above dataset we can say that,
1.There are total 159 rows and 9 features in the dataset.
2.There is numeric as well as string data in the dataset.
3.Happiness Score is the Y(output,independent) variable and all other features are the input(dependent) variables
4.This is a regression problem as almost all the features are in numeric continous data.
# In[171]:


df.isnull().sum()


# It is clearly visible that there are no null values present in the dataset.

# In[172]:


df.dtypes


# Country and Region are the features which are of string type. All other features are of numeric type.

# In[173]:


df.columns


# Name of each variable.

# In[174]:


df.info() #total count,not-null and dtype of each column


# ### Univariant, Bivariant, Multivariant Analysis

# In[175]:


sns.lmplot(x="Happiness Score",y="Happiness Rank",data=df)


# The above diagram clearly depicts that the Happiness Score is inversely related to Happiness Rank i.e more the Happiness Score
# less will be the Happiness Rank.
# We can aslo say that Happiness Score and Happiness Rank are negetively Correlated.

# In[176]:


sns.distplot(df["Standard Error"])


# From above we can state that, Standard Error is very slightly left skewed.

# In[177]:


sns.scatterplot(data=df,y="Economy (GDP per Capita)",x="Standard Error",hue="Happiness Score")


# From the above figure, we can see that less the Standard Error is, more the Economy per capita is more the Happiness Score is.

# In[178]:


sns.scatterplot(data=df,x="Economy (GDP per Capita)", y="Family", hue="Happiness Score")


# with the increasing Economy(GDP per capita) and Family More the Happiness Score is.

# In[179]:


plt.figure(figsize=(9,9))
sns.lmplot(data=df,x="Economy (GDP per Capita)", y="Family")


# We can see that there is a Linear Relationship between Economy(GDP per capita) and Family feature.

# In[180]:


sns.scatterplot(data=df,x="Economy (GDP per Capita)", y="Health (Life Expectancy)", hue="Happiness Score")


# With the increase in Economy(GDP per capita) and Health Life Expectancy more the Happiness Score will be.

# In[181]:


sns.lmplot(data=df,x="Economy (GDP per Capita)", y="Health (Life Expectancy)")


# Economy and Health are positively corelated.

# In[182]:


sns.scatterplot(data=df,y="Health (Life Expectancy)", x="Family", hue="Happiness Score")


# With the increasing heath(life expenctancy) and family more the happiness score is.

# In[183]:


sns.regplot(data=df,y="Health (Life Expectancy)", x="Family")


# Health( life expectancy) and family are linearLy propotional to each other.

# In[184]:


sns.scatterplot(data=df,x="Economy (GDP per Capita)", y="Freedom", hue="Happiness Score")


# The increase in freedom and economy(GDP per capita) the happiness score also increases.

# In[185]:


sns.scatterplot(data=df,x="Family", y="Freedom", hue="Happiness Score")


# With the increase in family and freedom the happiness score also increases.

# In[186]:


sns.scatterplot(data=df,x="Health (Life Expectancy)", y="Freedom", hue="Happiness Score")


# From above plot we can see that with the increase in health(life expectancy) and freedom happiness score also increases. Making it tough to predict the relation.

# In[187]:


sns.scatterplot(data=df,y="Freedom", x="Trust (Government Corruption)", hue="Happiness Score")


# From the above plot se can see that the relation between trust(government corruption), freedom and happiness score is very scattered.

# In[188]:


sns.scatterplot(data=df,x="Generosity", y="Freedom", hue="Happiness Score")


# with the increasing Generosity more the Freedom more is the Happiness Score is.

# In[189]:


sns.lmplot(data=df,x="Generosity", y="Family")


# The Family and generosity share a linear relationship but if we look at the slope in the above diagram it is more towards a strainght line. 

# In[190]:


sns.lmplot(data=df,y="Dystopia Residual", x="Happiness Score")


# Dystopia Residual and Happiness Score are sharing a healthy linear Relationship as per the above plot.

# In[191]:


sns.distplot(df["Dystopia Residual"])


# From the above plot we can see that Dystopia Residual is very slightly right skewed.

# In[192]:


sns.scatterplot(data=df,y="Dystopia Residual", x="Freedom", hue="Happiness Score")


# In the above plot, the relation amoung the Dystopia Residual Freedom and Happiness Score is very scattered making it tough to understand the relation.

# In[193]:


color=dict(boxes="Purple",whiskers="Red",medians="Pink",caps="Black")
df.plot(kind="box",subplots=True,layout=(2,6),figsize=(18,18),color=color)


# In the Above Boxplot, we can see that there is the presence of outliers in the various features like Trust(Government Corruption),Dystopia Residual,Standard Error and Family.
# We could also see through distribution plots for Standard Error and Dystopia Residual there was slight skewness present in these features and that was because of the presence of the outliers.
# It was tough to identify what kind of relation Trust(Government Corruption) is having with other features because of the presence of outliers.

# In[194]:


plt.figure(figsize=(10,10))
sns.heatmap(df.corr(),annot=True)


# In the above Heatmap,
# 1.We could see that Happiness Score and Happiness Rank are highly negetively corelated.
# 2.Family,Economy(GDP per capita) and Health(Life Expectancy) are positively corelated to each other and giving the maximum contribution in determining the Happiness Score.
# 3.Freedom and Trust(Government Corruption) are so corelated to each other.
# 4.Dystopia Residual is also contibuting positively in determining the Happiness Score.
# 5.For Standard Error, its hard to depict the relation with other features and Happiness score as its contributing negetively in depicting the Score.

# ### Data Preprocessing/Cleaning

# In[195]:


df.describe()

In the above descripton,
1.There is diffrence between the 75% and max for some of the features like Standard Error we can say that there is presence of outliers.
2.There is no major difference in the mean and 50% percentile of data but the presence of outliers are making some of the features skewed.
3.Std predicts that how much data is deviated from the mean and we could see that data is majorly spread around its mean making it normally distributed.
# In[196]:


df.skew()


# We can see that there is skewness in some of the features.

# In[197]:


df.drop("Country",axis=1,inplace=True)


# In[198]:


df.drop("Region",axis=1,inplace=True)


# In[199]:


df.drop("Happiness Rank", axis=1, inplace=True)


# We could see that Country and Region are the string data and are not required for predicting Happiness Score we can drop thoes columns and Happiness Rank is negetively highly corelated to each other we can aslo drop Happiness Rank.

# ### Removing outliers

# In[200]:


zp=np.abs(zscore(df))   #removing outliers present the dataset
zp
threshold=3
print(np.where(zp>3))


# In[201]:


df_new=df[(zp<3).all(axis=1)]
df_new


# The rows have reduced to 150 after removing the outliers present in the dataset.

# In[202]:


df_new.skew()


# We can see that after removing the outliers the skewness of the parameters have reduced to much extent.

# ### Dividing the dataset: X(Independent) and Y(Dependent) Variables

# In[203]:


x=df_new.iloc[:,1:]
x


# In[204]:


y=df_new.iloc[:,0]
y


# In[205]:


y.shape


# ### VIF Calculation

# In[206]:


def calc_vif(x):                #Variance Inflation Factor
    vif=pd.DataFrame()
    vif["variables"]=x.columns
    vif["VIF FACTOR"]=[variance_inflation_factor(x.values,i) for i in range (x.shape[1])]
    return(vif)


# In[207]:


calc_vif(x)


# From above we can see that, the vif factors of each and every column is not that high i.e chances of multicolinearity is very less I would like to remove any column as each and feature is giving its own contribution in predicting the Happiness Score

# ### Performing Algorithms
Performing Train-test-split and as it is a Regression problem various classification algorithms performed are:
1: Linear Regression Algorithm
2: Lasso Regression Algorithm
3: Ridge Regression Algorithm
4: Support Vector Regression Algorithm.
# In[208]:


minmse=0    #finding the best Random State
maxrs=0
for i in range(1,100):
    x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=.30,random_state=i)
    lr=LinearRegression()
    lr.fit(x_train,y_train)
    pred=lr.predict(x_test)
# WARNING: Multi Test Leakage — test data is being used improperly before final evaluation.
# QUICK FIX: Use a proper Train/Validation/Test split to ensure test data is untouched until final evaluation.
    err=mean_squared_error(y_test,pred)
    if err>minmse:
        minmse=err
        maxrs=i
print("MSE is ",round(maxacc,2),"at random state",maxrs)


# In[209]:


x_train1,x_test1,y_train1,y_test1=train_test_split(x,y,test_size=.30,random_state=83)


# ### 1.Linear Regression

# In[210]:


lr=LinearRegression()
lr.fit(x_train1,y_train1)
print("Cofficient is:",lr.coef_)
print("Intercept is: ",lr.intercept_)
sco=lr.score(x_train1,y_train1)
sco1=sco*100
print("Score is: ",sco1)
pred=lr.predict(x_test1)


# In[211]:


mse=mean_squared_error(y_test1,pred)
print("Mean Squared Error is: ",round(mse,2))
abse=mean_absolute_error(y_test1,pred)
print("Mean Absolute Error is: ",round(abse,2))
scr=r2_score(y_test1,pred)
print("R2 Score is: ",round(scr,2))


# ### 2.Lasso Regression

# In[228]:


lst=[1,0.01,0.001,0.0001]   #finding the best value of alpha
for i in lst:
    ls=Lasso(alpha=i)
    ls.fit(x_train1,y_train1)
    ls.score(x_train1,y_train1)
    pred=ls.predict(x_test1)
    print("Mean Squared Error is: ",round(mean_squared_error(y_test1,pred),2),"for the value of alpha:",i)
    print("Mean Absolute Error is: ",round(mean_absolute_error(y_test1,pred),2),"for the value of alpha:",i)
    print("R2_Score is: ",round(r2_score(y_test1,pred),2),"for the value of alpha:",i)


# In[231]:


ls1=Lasso(alpha=0.001)   #choosing the best alpha
ls1.fit(x_train1,y_train1)
sw=ls1.score(x_train1,y_train1)
print("Coffecient is: ",ls1.coef_)
print("Intercept is: ",ls1.intercept_)
print("Score is: ",sw)
pred=ls1.predict(x_test1)
print("Mean Squared Error is:",round(mean_squared_error(y_test1,pred),2))
print("Mean Absolute Error is:",round(mean_absolute_error(y_test1,pred),2))
print("R2 Score is:",round(r2_score(y_test1,pred),2))


# ### 3.Ridge Regression

# In[232]:


lst=[1,0.01,0.001,0.0001]
for i in lst:
    lt=Ridge(alpha=i)
    lt.fit(x_train1,y_train1)
    lt.score(x_train1,y_train1)
    pred=lt.predict(x_test1)
    print("Mean Squared Error is:",round(mean_squared_error(y_test1,pred),2),"for the value of alpha: ",i)
    print("Mean Absolute Error is: ",round(mean_absolute_error(y_test1,pred),2),"for the value of alpha: ",i)
    print("R2 Score is: ",round(r2_score(y_test1,pred),2),"for the value of aplha: ",i)


# In[233]:


lt1=Ridge(alpha=0.001) #choosing the best alpha
lt1.fit(x_train1,y_train1)
sw1=lt1.score(x_train1,y_train1)
print("Coffecient is: ",lt1.coef_)
print("Intercept is: ",lt1.intercept_)
print("Score is: ",sw1)
pred=lt1.predict(x_test1)
print("Mean Squared Error is:",round(mean_squared_error(y_test1,pred),2))
print("Mean Absolute Error is:",round(mean_absolute_error(y_test1,pred),2))
print("R2 Score is:",round(r2_score(y_test1,pred),2))


# ### 4.Support Vector Regressor

# In[234]:


ker=["rbf","poly","linear"]    #finding the best kernel
for i in ker:
    svr=SVR(kernel=i)
    svr.fit(x_train1,y_train1)
    pred=svr.predict(x_test1)
    print("For",i,"Mean Squared Error is:",round(mean_squared_error(y_test1,pred),2))
    print("For",i,"Mean Absolute Error is:",round(mean_absolute_error(y_test1,pred),2))
    print("For",i,"R2 Score is:",round(r2_score(y_test1,pred),2))


# In[235]:


svr1=SVR(kernel="linear")
svr1.fit(x_train1,y_train1)
sw2=svr1.score(x_train1,y_train1)
print("Coffecient is: ",svr1.coef_)
print("Intercept is: ",svr1.intercept_)
print("Score is: ",sw2)
pred=svr1.predict(x_test1)
print("Mean Squared Error is:",round(mean_squared_error(y_test1,pred),2))
print("Mean Absolute Error is:",round(mean_absolute_error(y_test1,pred),2))
print("R2 Score is:",round(r2_score(y_test1,pred),2))


# ### Cross Validation Score

# In[218]:


print(cross_val_score(svr1,x,y,cv=5).mean()) #Support Vector Regressor


# In[219]:


print(cross_val_score(lr,x,y,cv=5).mean()) #Linear Regressor


# In[220]:


print(cross_val_score(lt1,x,y,cv=5).mean()) #Ridge Regressor


# In[221]:


print(cross_val_score(ls1,x,y,cv=5).mean()) #lasso Regressor


# Comparing all the above models there MSE, MAS,R2 Scores and Cross validation scores of each model we can see that Linear Regression is giving us the best results with MSE:0 MAS:0 and R2 Score:100 and Cross validation score:100
# In my opnion Linear Regression is the best perfroming model for the above dataset

# ### Hyper Parameter Tunning using GridSearchCV

# In[222]:


parameter={"fit_intercept":[True,False],
          "normalize":[True,False],
          "copy_X":[True,False],
          "n_jobs":np.arange(2,20),
          "positive":[True,False]}


# In[223]:


gcv=GridSearchCV(LinearRegression(),parameter,cv=5)


# In[224]:


gcv.fit(x_train1,y_train1)


# In[225]:


gcv.best_params_  #best parameters


# ### Final Model

# In[240]:


final=LinearRegression(copy_X=True,fit_intercept=False,n_jobs=2,normalize=True,positive=False)
final.fit(x_train1,y_train1)
print("Cofficient is:",final.coef_)
print("Intercept is: ",final.intercept_)
sco1=final.score(x_train1,y_train1)
sco2=sco*100
print("Score is: ",sco2)
pred=final.predict(x_test1)
mse=mean_squared_error(y_test1,pred)
print("Mean Squared Error is: ",round(mse,2))
abse=mean_absolute_error(y_test1,pred)
print("Mean Absolute Error is: ",round(abse,2))
scr=r2_score(y_test1,pred)
print("R2 Score is: ",round(scr,2))


# ### Saving the model

# In[241]:


import joblib
joblib.dump(final,"finalmod1.pkl")

